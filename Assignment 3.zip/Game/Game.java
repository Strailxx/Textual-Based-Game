package Game;

public class Game {
    public static void main(String[] args) {
        Duel duelGame = new Duel();
        duelGame.run();
    }
}
